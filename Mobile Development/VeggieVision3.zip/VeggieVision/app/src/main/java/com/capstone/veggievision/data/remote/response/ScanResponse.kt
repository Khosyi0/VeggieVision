package com.capstone.veggievision.data.remote.response

data class ScanResponse(
    val Label: String,
    val Percentage: String
)
